package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import DB.CarpoolDB;
import DB.ProfileDB;

import java.util.ArrayList;


import OBJ.Carpool;
import OBJ.User;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import java.net.URL;
import javafx.fxml.Initializable;
import java.util.ResourceBundle;

public class RidePickerController extends SwitchHud implements Initializable{

	@FXML
	Button bRidePicked0;
	Button bRidePicked1;
	Button bRidePicked2;
	Button bRidePicked3;
	Button bRidePicked4;
	Button bRidePicked5;
	Button bRidePicked6;
	Button bRidePicked7;
	Button bRidePicked8;
	Button bRidePicked9;


	private Stage stage;
	private Scene scene;
	private Parent root;



	@FXML // first ride text
	Text FirstNameLabel1,
	LastNameLabel1,
	RidesCompletedLabel1,
	DepartWeekLabel1,
	DepartTimeLabel1,
	DepartAMPMLabel1,
	DepartCityLabel1,
	ArriveWeekLabel1,
	ArriveTimeLabel1,
	ArriveAMPMLabel1,
	ArriveCityLabel1;

	@FXML // Second ride text
	Text FirstNameLabel2,
	LastNameLabel2,
	RidesCompletedLabel2,
	DepartWeekLabel2,
	DepartTimeLabel2,
	DepartAMPMLabel2,
	DepartCityLabel2,
	ArriveWeekLabel2,
	ArriveTimeLabel2,
	ArriveAMPMLabel2,
	ArriveCityLabel2;

	@FXML // Third ride text
	Text FirstNameLabel3,
	LastNameLabel3,
	RidesCompletedLabel3,
	DepartWeekLabel3,
	DepartTimeLabel3,
	DepartAMPMLabel3,
	DepartCityLabel3,
	ArriveWeekLabel3,
	ArriveTimeLabel3,
	ArriveAMPMLabel3,
	ArriveCityLabel3;

	@FXML // Fourth ride text
	Text FirstNameLabel4,
	LastNameLabel4,
	RidesCompletedLabel4,
	DepartWeekLabel4,
	DepartTimeLabel4,
	DepartAMPMLabel4,
	DepartCityLabel4,
	ArriveWeekLabel4,
	ArriveTimeLabel4,
	ArriveAMPMLabel4,
	ArriveCityLabel4;

	@FXML // Fifth ride text
	Text FirstNameLabel5,
	LastNameLabel5,
	RidesCompletedLabel5,
	DepartWeekLabel5,
	DepartTimeLabel5,
	DepartAMPMLabel5,
	DepartCityLabel5,
	ArriveWeekLabel5,
	ArriveTimeLabel5,
	ArriveAMPMLabel5,
	ArriveCityLabel5;

	@FXML // Sixth
	Text FirstNameLabel6,
	LastNameLabel6,
	RidesCompletedLabel6,
	DepartWeekLabel6,
	DepartTimeLabel6,
	DepartAMPMLabel6,
	DepartCityLabel6,
	ArriveWeekLabel6,
	ArriveTimeLabel6,
	ArriveAMPMLabel6,
	ArriveCityLabel6;

	@FXML // 7
	Text FirstNameLabel7,
	LastNameLabel7,
	RidesCompletedLabel7,
	DepartWeekLabel7,
	DepartTimeLabel7,
	DepartAMPMLabel7,
	DepartCityLabel7,
	ArriveWeekLabel7,
	ArriveTimeLabel7,
	ArriveAMPMLabel7,
	ArriveCityLabel7;

	@FXML // 8
	Text FirstNameLabel8,
	LastNameLabel8,
	RidesCompletedLabel8,
	DepartWeekLabel8,
	DepartTimeLabel8,
	DepartAMPMLabel8,
	DepartCityLabel8,
	ArriveWeekLabel8,
	ArriveTimeLabel8,
	ArriveAMPMLabel8,
	ArriveCityLabel8;

	@FXML // 9
	Text FirstNameLabel9,
	LastNameLabel9,
	RidesCompletedLabel9,
	DepartWeekLabel9,
	DepartTimeLabel9,
	DepartAMPMLabel9,
	DepartCityLabel9,
	ArriveWeekLabel9,
	ArriveTimeLabel9,
	ArriveAMPMLabel9,
	ArriveCityLabel9;

	@FXML // 0
	Text FirstNameLabel0,
	LastNameLabel0,
	RidesCompletedLabel0,
	DepartWeekLabel0,
	DepartTimeLabel0,
	DepartAMPMLabel0,
	DepartCityLabel0,
	ArriveWeekLabel0,
	ArriveTimeLabel0,
	ArriveAMPMLabel0,
	ArriveCityLabel0;

	/**
	 * DONT TOUCH THIS
	 * RidePickedBtn sends user to the confirmation screen
	 * @param event | button press
	 * @throws IOException
	 */
	public void RidePickedBtn1(ActionEvent event) throws IOException{
		DriverClass.magicNumber = 1;
		Parent root = FXMLLoader.load(getClass().getResource("ConfirmRide.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

	}
	public void RidePickedBtn2(ActionEvent event) throws IOException{
		DriverClass.magicNumber = 2;
		Parent root = FXMLLoader.load(getClass().getResource("ConfirmRide.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

	}
	public void RidePickedBtn3(ActionEvent event) throws IOException{
		DriverClass.magicNumber = 3;
		Parent root = FXMLLoader.load(getClass().getResource("ConfirmRide.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

	}
	public void RidePickedBtn4(ActionEvent event) throws IOException{
		DriverClass.magicNumber = 4;
		Parent root = FXMLLoader.load(getClass().getResource("ConfirmRide.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

	}
	public void RidePickedBtn5(ActionEvent event) throws IOException{
		DriverClass.magicNumber = 5;
		Parent root = FXMLLoader.load(getClass().getResource("ConfirmRide.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

	}
	public void RidePickedBtn6(ActionEvent event) throws IOException{
		DriverClass.magicNumber = 6;
		Parent root = FXMLLoader.load(getClass().getResource("ConfirmRide.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

	}
	public void RidePickedBtn7(ActionEvent event) throws IOException{
		DriverClass.magicNumber = 7;
		Parent root = FXMLLoader.load(getClass().getResource("ConfirmRide.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

	}
	public void RidePickedBtn8(ActionEvent event) throws IOException{
		DriverClass.magicNumber = 8;
		Parent root = FXMLLoader.load(getClass().getResource("ConfirmRide.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

	}
	public void RidePickedBtn9(ActionEvent event) throws IOException{
		DriverClass.magicNumber = 9;
		Parent root = FXMLLoader.load(getClass().getResource("ConfirmRide.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

	}
	public void RidePickedBtn0
	(ActionEvent event) throws IOException{
		DriverClass.magicNumber = 0;
		Parent root = FXMLLoader.load(getClass().getResource("ConfirmRide.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

	}

	@Override // actions which occour when the scene is loaded
	public void initialize(URL url, ResourceBundle resourceBundle){




		try {

			updateLabels(DriverClass.myCarpools, DriverClass.myProfiles);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("sql excewption happenewd Owo");
			e.printStackTrace();
		}
	}

	/**
	 * Updates Ride Variables
	 * @author Angel
	 * @throws SQLException
	 */
	public void updateLabels(CarpoolDB cpDB, ProfileDB pfDB) throws SQLException {

		// Gets List of Carpools
		List<Carpool> carpools = new ArrayList<>();
		List<User> profiles = new ArrayList<>(); // Gets User Id

		carpools = cpDB.getCarpoolList();

		for(Carpool x:carpools) {
			profiles.add( pfDB.getUserById(x.getDriverID())); // Gets driver's profile & new funciton in ProfileDB
		}

		// Populates stuff

		FirstNameLabel0.setText(profiles.get(0).getFirstName());
		System.out.println(FirstNameLabel0.getText());
		LastNameLabel0.setText(profiles.get(0).getLastName());
		RidesCompletedLabel0.setText(Integer.toString(profiles.get(0).getridesJoined()));
		DepartWeekLabel0.setText(carpools.get(0).getPickupDate());
		DepartTimeLabel0.setText(carpools.get(0).getPickupTime());
		DepartAMPMLabel0.setText(carpools.get(0).getPickupMeridiem());
		DepartCityLabel0.setText(DriverClass.magicStart);
		ArriveWeekLabel0.setText(carpools.get(0).getPickupDate());
		ArriveTimeLabel0.setText(carpools.get(0).getPickupTime());
		ArriveAMPMLabel0.setText(carpools.get(0).getArrivalMeridiem());
		ArriveCityLabel0.setText(DriverClass.magicEnd);

		FirstNameLabel1.setText(profiles.get(1).getFirstName());
		LastNameLabel1.setText(profiles.get(1).getLastName());
		RidesCompletedLabel1.setText(Integer.toString(profiles.get(1).getridesJoined()));
		DepartWeekLabel1.setText(carpools.get(1).getPickupDate());
		DepartTimeLabel1.setText(carpools.get(1).getPickupTime());
		DepartAMPMLabel1.setText(carpools.get(1).getPickupMeridiem());
		DepartCityLabel1.setText(DriverClass.magicStart);
		ArriveWeekLabel1.setText(carpools.get(1).getPickupDate());
		ArriveTimeLabel1.setText(carpools.get(1).getPickupTime());
		ArriveAMPMLabel1.setText(carpools.get(1).getArrivalMeridiem());
		ArriveCityLabel1.setText(DriverClass.magicEnd);

		FirstNameLabel2.setText(profiles.get(2).getFirstName());
		LastNameLabel2.setText(profiles.get(2).getLastName());
		RidesCompletedLabel2.setText(Integer.toString(profiles.get(2).getridesJoined()));
		DepartWeekLabel2.setText(carpools.get(2).getPickupDate());
		DepartTimeLabel2.setText(carpools.get(2).getPickupTime());
		DepartAMPMLabel2.setText(carpools.get(2).getPickupMeridiem());
		DepartCityLabel2.setText(DriverClass.magicStart);
		ArriveWeekLabel2.setText(carpools.get(2).getPickupDate());
		ArriveTimeLabel2.setText(carpools.get(2).getPickupTime());
		ArriveAMPMLabel2.setText(carpools.get(2).getArrivalMeridiem());
		ArriveCityLabel2.setText(DriverClass.magicEnd);

		FirstNameLabel3.setText(profiles.get(3).getFirstName());
		LastNameLabel3.setText(profiles.get(3).getLastName());
		RidesCompletedLabel3.setText(Integer.toString(profiles.get(3).getridesJoined()));
		DepartWeekLabel3.setText(carpools.get(3).getPickupDate());
		DepartTimeLabel3.setText(carpools.get(3).getPickupTime());
		DepartAMPMLabel3.setText(carpools.get(3).getPickupMeridiem());
		DepartCityLabel3.setText(DriverClass.magicStart);
		ArriveWeekLabel3.setText(carpools.get(3).getPickupDate());
		ArriveTimeLabel3.setText(carpools.get(3).getPickupTime());
		ArriveAMPMLabel3.setText(carpools.get(3).getArrivalMeridiem());
		ArriveCityLabel3.setText(DriverClass.magicEnd);

		FirstNameLabel4.setText(profiles.get(4).getFirstName());
		LastNameLabel4.setText(profiles.get(4).getLastName());
		RidesCompletedLabel4.setText(Integer.toString(profiles.get(4).getridesJoined()));
		DepartWeekLabel4.setText(carpools.get(4).getPickupDate());
		DepartTimeLabel4.setText(carpools.get(4).getPickupTime());
		DepartAMPMLabel4.setText(carpools.get(4).getPickupMeridiem());
		DepartCityLabel4.setText(DriverClass.magicStart);
		ArriveWeekLabel4.setText(carpools.get(4).getPickupDate());
		ArriveTimeLabel4.setText(carpools.get(4).getPickupTime());
		ArriveAMPMLabel4.setText(carpools.get(4).getArrivalMeridiem());
		ArriveCityLabel4.setText(DriverClass.magicEnd);

		FirstNameLabel5.setText(profiles.get(5).getFirstName());
		LastNameLabel5.setText(profiles.get(5).getLastName());
		RidesCompletedLabel5.setText(Integer.toString(profiles.get(5).getridesJoined()));
		DepartWeekLabel5.setText(carpools.get(5).getPickupDate());
		DepartTimeLabel5.setText(carpools.get(5).getPickupTime());
		DepartAMPMLabel5.setText(carpools.get(5).getPickupMeridiem());
		DepartCityLabel5.setText(DriverClass.magicStart);
		ArriveWeekLabel5.setText(carpools.get(5).getPickupDate());
		ArriveTimeLabel5.setText(carpools.get(5).getPickupTime());
		ArriveAMPMLabel5.setText(carpools.get(5).getArrivalMeridiem());
		ArriveCityLabel5.setText(DriverClass.magicEnd);

		FirstNameLabel6.setText(profiles.get(6).getFirstName());
		LastNameLabel6.setText(profiles.get(6).getLastName());
		RidesCompletedLabel6.setText(Integer.toString(profiles.get(6).getridesJoined()));
		DepartWeekLabel6.setText(carpools.get(6).getPickupDate());
		DepartTimeLabel6.setText(carpools.get(6).getPickupTime());
		DepartAMPMLabel6.setText(carpools.get(6).getPickupMeridiem());
		DepartCityLabel6.setText(DriverClass.magicStart);
		ArriveWeekLabel6.setText(carpools.get(6).getPickupDate());
		ArriveTimeLabel6.setText(carpools.get(6).getPickupTime());
		ArriveAMPMLabel6.setText(carpools.get(6).getArrivalMeridiem());
		ArriveCityLabel6.setText(DriverClass.magicEnd);

		FirstNameLabel7.setText(profiles.get(7).getFirstName());
		LastNameLabel7.setText(profiles.get(7).getLastName());
		RidesCompletedLabel7.setText(Integer.toString(profiles.get(7).getridesJoined()));
		DepartWeekLabel7.setText(carpools.get(7).getPickupDate());
		DepartTimeLabel7.setText(carpools.get(7).getPickupTime());
		DepartAMPMLabel7.setText(carpools.get(7).getPickupMeridiem());
		DepartCityLabel7.setText(DriverClass.magicStart);
		ArriveWeekLabel7.setText(carpools.get(7).getPickupDate());
		ArriveTimeLabel7.setText(carpools.get(7).getPickupTime());
		ArriveAMPMLabel7.setText(carpools.get(7).getArrivalMeridiem());
		ArriveCityLabel7.setText(DriverClass.magicEnd);

		FirstNameLabel8.setText(profiles.get(8).getFirstName());
		LastNameLabel8.setText(profiles.get(8).getLastName());
		RidesCompletedLabel8.setText(Integer.toString(profiles.get(8).getridesJoined()));
		DepartWeekLabel8.setText(carpools.get(8).getPickupDate());
		DepartTimeLabel8.setText(carpools.get(8).getPickupTime());
		DepartAMPMLabel8.setText(carpools.get(8).getPickupMeridiem());
		DepartCityLabel8.setText(DriverClass.magicStart);
		ArriveWeekLabel8.setText(carpools.get(8).getPickupDate());
		ArriveTimeLabel8.setText(carpools.get(8).getPickupTime());
		ArriveAMPMLabel8.setText(carpools.get(8).getArrivalMeridiem());
		ArriveCityLabel8.setText(DriverClass.magicEnd);

		FirstNameLabel9.setText(profiles.get(9).getFirstName());
		LastNameLabel9.setText(profiles.get(9).getLastName());
		RidesCompletedLabel9.setText(Integer.toString(profiles.get(9).getridesJoined()));
		DepartWeekLabel9.setText(carpools.get(9).getPickupDate());
		DepartTimeLabel9.setText(carpools.get(9).getPickupTime());
		DepartAMPMLabel9.setText(carpools.get(9).getPickupMeridiem());
		DepartCityLabel9.setText(DriverClass.magicStart);
		ArriveWeekLabel9.setText(carpools.get(9).getPickupDate());
		ArriveTimeLabel9.setText(carpools.get(9).getPickupTime());
		ArriveAMPMLabel9.setText(carpools.get(9).getArrivalMeridiem());
		ArriveCityLabel9.setText(DriverClass.magicEnd);

	}


}

/*
Freedom!
Freedom!
Forgive me!
Retake Retake!
Victorious, triumphant!
All of my kingdom
For your return
I'd let it all burn!
I'd let it all burn!
Dear departed
I'll cry for you in a dream
Now I must rise to be queen
Be worthy!
Be worthy!
*/