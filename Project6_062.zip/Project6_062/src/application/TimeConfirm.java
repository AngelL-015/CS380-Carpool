package application;


import java.text.ParseException;
import java.text.SimpleDateFormat;

public class TimeConfirm {

	// checks 4 date
    public static boolean isValidDate(String inDate) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("mm/dd/yyyy");
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(inDate.trim());
        } catch (ParseException pe) {
            return false;
        }
        return true;
    }

    // 12:30
    // 1:00 PM
    public static boolean isValidTime(String inTime){
		try{
	    	if (inTime.length() == 7){
	    		inTime = "0" + inTime;
			}
			char[] arrTime = inTime.toCharArray();

			//checks length
			boolean bool0 = false;
			if (inTime.length() == 8){
				bool0 = true;
			}

			// checks hour
			boolean bool1 = false;
			if (inTime.substring(0,2).equals("01") || inTime.substring(0,2).equals("02") || inTime.substring(0,2).equals("03") ||
					inTime.substring(0,2).equals("04") || inTime.substring(0,2).equals("05") || inTime.substring(0,2).equals("06")||
					inTime.substring(0,2).equals("07") || inTime.substring(0,2).equals("08") || inTime.substring(0,2).equals("09")||
					inTime.substring(0,2).equals("10") || inTime.substring(0,2).equals("11") || inTime.substring(0,2).equals("12")){
				bool1 = true;
			}







			//checks for colon
			boolean bool2 = false;
			if (arrTime[2] == ':'){
				bool2 = true;
			}

			// checks for decamin
			boolean bool3 = false;
			if (arrTime[3] == '1' || arrTime[3] == '2' || arrTime[3] == '3' ||
					arrTime[3] == '4' || arrTime[3] == '5' || arrTime[3] == '0'){
				bool3 = true;
			}

			// checks for min
			boolean bool4 = false;
			if (arrTime[4] == '1' || arrTime[4] == '2' || arrTime[4] == '3' ||
					arrTime[4] == '4' || arrTime[4] == '5' || arrTime[4] == '6'||
					arrTime[4] == '7' || arrTime[4] == '8' || arrTime[4] == '9' || arrTime[4] == '0'){
				bool4 = true;
			}

			// checks for space
			boolean bool5 = false;
			if (arrTime[5] == ' '){
				bool5 = true;
			}

			// checks for space
			boolean bool6 = false;
			if (arrTime[6] == 'P' || arrTime[6] == 'A' ||
					arrTime[6] == 'p' || arrTime[6] == 'a'){
				bool6 = true;
			}

			// checks for space
			boolean bool7 = false;
			if (arrTime[7] == 'M' || arrTime[7] == 'm'){
				bool7 = true;
			}


			if(bool0 == true && bool1 == true && bool2 == true &&
					bool3 == true && bool4 == true && bool5 == true &&
					bool6 == true && bool7){
				return true;
			}
		}
		catch (Exception oops) {
	            return false;
	    }

	return false;
    }

    public static boolean spaceLeft(String inLabel, String inText){
    	try{


    	int currentInt = Integer.parseInt(inLabel.substring(0,1));
    	int capInt = Integer.parseInt(inLabel.substring(2,3));
    	int textInt = Integer.parseInt(inText);

    	if (textInt >= 1){
    		if ((textInt + currentInt) <= capInt){
    			return true;
    		}
    	}




    	return false;
    	}
    	catch (Exception oops) {
    		return false;
    	}
    }











	// Main method that launches the veiwer.
	public static void main(String[] args) {
		if(isValidDate("12/1/2023") == true){
		System.out.println("true");
		}
		else{
			System.out.println("false");
		}


		if(isValidTime("1:10 Pm") == true){
		System.out.println("true");
		}
		else{
			System.out.println("false");
		}

		if(spaceLeft("2/5", "4") == true){
		System.out.println("true");
		}
		else{
			System.out.println("false");
		}




	}

}
