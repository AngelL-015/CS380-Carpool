/**
 * Driver PhoneReveiwsController: Contians method for input and output of PhoneReveiws scene.
 * @author Ian Nelson
 * Date 6/1/2023
 * CS380 Lab 5
 * Prof. Dovhalets
 *
 */

package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DB.CarpoolDB;
import DB.ProfileDB;
import DB.ReviewDB;
import OBJ.Carpool;
import OBJ.Review;
import OBJ.User;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;

/**
 * This is a class controller for the phoneReveiws scene
 * @author iann
 *
 */
public class PhoneReviewsController extends SwitchHud {

	@FXML // Labels at the top of the page
	Text DriverNameLabel, RidesCompletedLabel;

	@FXML // Pic at the top of the page
	ImageView DriverPFPImage;

	@FXML // Review messages, and name/time
	Text MessageTextLabel1, NameAndTimeLabel1, MessageTextLabel2, NameAndTimeLabel2,
		MessageTextLabel3, NameAndTimeLabel3, MessageTectLabel4,	NameAndTimeLabel4,
		MessageTextLabel5, NameAndTimeLabel5;

	@FXML // Review message stars, saved as image
	ImageView StarImage1, StarImage2, StarImage3, StarImage4, StarImage5;

	
	/**
	 * Function Updates Review Variables
	 * @author Angel
	 */
	public void updateLabels(ReviewDB rvDB) throws SQLException  {
		
		// Sets ArrayList
		List<Review> reviews = new ArrayList<>();
		
		// Populates array list
		reviews = rvDB.getReviewsAsDriver(0);
		
		// Updates Text Labels
		MessageTextLabel1.setText(reviews.get(0).getComment());
		NameAndTimeLabel1.setText(ProfileDB.getNameById(reviews.get(0).getPassengerID()) 
				+ reviews.get(1).getDate());//? 
		
		MessageTextLabel2.setText(reviews.get(1).getComment());
		NameAndTimeLabel2.setText(ProfileDB.getNameById(reviews.get(1).getPassengerID()) 
				+ reviews.get(2).getDate());
		
		MessageTextLabel3.setText(reviews.get(2).getComment());
		NameAndTimeLabel3.setText(ProfileDB.getNameById(reviews.get(2).getPassengerID()) 
				+ reviews.get(3).getDate());
		
		MessageTectLabel4.setText(reviews.get(3).getComment());
		NameAndTimeLabel4.setText(ProfileDB.getNameById(reviews.get(3).getPassengerID()) 
				+ reviews.get(3).getDate());
		
		MessageTextLabel5.setText(reviews.get(4).getComment());
		NameAndTimeLabel5.setText(ProfileDB.getNameById(reviews.get(4).getPassengerID()) 
				+ reviews.get(3).getDate());
		
		
	}


}
