package DB;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

// Janky classes
public class DBSortingUtils {
	
	private Connection con;
	
	public DBSortingUtils(Connection con) {
        this.con = con;
    }
	
	public ResultSet sortByDefault(Connection con) throws SQLException {
		String query = "SELECT * FROM carpools";
		Statement stmt = con.createStatement();
		ResultSet rslt = stmt.executeQuery(query);
		return rslt;
	}
	
	public ResultSet sortByTimeAsc(Connection con) throws SQLException {
		String query = "SELECT * FROM carpools ORDER BY pickupDate ASC, pickupTime ASC";
		Statement stmt = con.createStatement();
		ResultSet rslt = stmt.executeQuery(query);
		return rslt;
	}
	
	public ResultSet sortByTimeDesc(Connection con) throws SQLException {
		String query = "SELECT * FROM carpools ORDER BY pickupDate DESC, pickupTime DESC";
		Statement stmt = con.createStatement();
		ResultSet rslt = stmt.executeQuery(query);
		return rslt;
	}
	
	public ResultSet sortByKeysAsc(Connection con) throws SQLException {
		String query = "select * from carpools order by carpoolId asc";
		Statement stmt = con.createStatement();
		ResultSet rslt = stmt.executeQuery(query);
		return rslt;
	}
	
	public void sortByKeysDesc(Connection con) throws SQLException {
		String query = "select * from carpools order by carpoolId desc";
		Statement stmt = con.createStatement();
		stmt.execute(query);	
	}
	
	public void sortByDriverNameAsc(Connection con) throws SQLException {
		String query = "SELECT c.*, p.lastName AS driverLastName"
			+ "FROM carpools AS c"
			+ "JOIN profiles p ON c.driverId = p.userId"
			+ "ORDER BY p.lastName";
		Statement stmt = con.createStatement();
		stmt.execute(query);	
	}
	
	public void sortByDriverNameDesc(Connection con) throws SQLException {
		String query = "SELECT c.*, p.lastName AS driverLastName"
			+ "FROM carpools AS c"
			+ "JOIN profiles p ON c.driverId = p.userId"
			+ "ORDER BY p.lastName";
		Statement stmt = con.createStatement();
		stmt.execute(query);	
	}
	
	public void sortByPassengerTotalAsc(Connection con) throws SQLException {
		String query = "SELECT c.*, COUNT(cp.passengerId) AS passengerCount"
			+ "FROM carpools AS c"
			+ "LEFT JOIN carpoolPassenger cp ON c.carpoolId = cp.carpoolId"
			+ "GROUP BY c.carpoolId"
			+ "ORDER BY passengerCount DESC";
		Statement stmt = con.createStatement();
		stmt.execute(query);	
	}
	
	public void sortByPassengerTotalDesc(Connection con) throws SQLException {
		String query = "SELECT c.*, COUNT(cp.passengerId) AS passengerCount"
			+ "FROM carpools AS c"
			+ "LEFT JOIN carpoolPassenger cp ON c.carpoolId = cp.carpoolId"
			+ "GROUP BY c.carpoolId"
			+ "ORDER BY passengerCount DESC";
			Statement stmt = con.createStatement();
			stmt.execute(query);	
		}
	
	public static Connection connect() {
		
		String url = "jdbc:mysql://127.0.0.1:3306/carpool_db";
		String userName = "root";
		String pass = "mathew123";
		
		try {
			Connection con = DriverManager.getConnection(url, userName, pass);
			System.out.println("connected");
			return con;
			
		}catch(Exception e) {
			System.out.println("exception " + e.getMessage());
			return null;
		}
	}
	
	public static void main(String[] args) {
		final Connection con = DBSortingUtils.connect();
		DBSortingUtils utils = new DBSortingUtils(con);
		ResultSet test;
		try {
			test = utils.sortByKeysAsc(con);
			System.out.println(test);
			while(test.next())
	        {
	        System.out.println(test.getString(6));
	        System.out.println(test.getString(7));
	        }
		}
		catch(Exception e) {
			System.out.println("not working");	
		}
		
	}

}