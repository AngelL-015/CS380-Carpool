/**
 * Driver ConfirmRideController: Contians method for input and output of ConfirmRide scene.
 * @author Ian Nelson
 * Date 6/1/2023
 * CS380 Lab 5
 * Prof. Dovhalets
 *
 */

package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
import DB.CarpoolDB;
import DB.ProfileDB;
import OBJ.Carpool;
import OBJ.User;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;

/**
 * look at the READ ME if you wanna know how to do a few things
 *
 */





/**
 * This class creates the stage, and loads the opening login scene.
 * @author Ian Nelson
 *
 */
public class DriverClass extends Application {

	/**
	 * Loads the stage window
	 * @param primaryStage | stage window
	 */
	@Override
	public void start(Stage primaryStage) throws Exception{



			/**
			 * This sets the name of the stage, and the frame in it.
			 */
			primaryStage.setTitle("Flock");
			Parent PhoneLoginScene = FXMLLoader.load(getClass().getResource("PhoneLogin.fxml"));
			primaryStage.setScene(new Scene(PhoneLoginScene,360,640));
			primaryStage.show();


	}

	/**
	 * The XLT block
	 */


	/**
	 * This is the pov users profile
	 */
	public static User myUser = new User(69420, "Josh", "Juggins", "JBoss@AOL.com", "(999) 999-9999", "234 Board Av. Southtown");
	public static User myUser2 = new User(69421, "Jared", "Smith", "JSmith@AOL.com", "(222) 999-9999", "154 fart Av. Buttstown");
	public static User myUser3 = new User(69422, "Jone", "Jones", "JJone@AOL.com", "(333) 999-9999", "934 fart Av. Buttstown");
	public static User myUser4 = new User(69423, "Sam", "Jackson", "JJack@AOL.com", "(444) 999-9999", "1308 fart Av. Buttstown");
	public static User myUser5 = new User(69424, "Sally", "Doe", "JDoe@AOL.com", "(555) 999-9999", "853 fart Av. Buttstown");
	public static User myUser6 = new User(69425, "Holly", "Henderson", "JHen@AOL.com", "(666) 999-9999", "9385 fart Av. Buttstown");
	public static User myUser7 = new User(69426, "Helga", "Lone", "JLone@AOL.com", "(767) 999-9999", "1324 fart Av. Buttstown");
	public static User myUser8 = new User(69427, "Happy", "Sanders", "JSand@AOL.com", "(888) 999-9999", "899 fart Av. Buttstown");
	public static User myUser9 = new User(69428, "James", "Johnson", "JJohn@AOL.com", "(121) 999-9999", "9238 fart Av. Buttstown");
	public static User myUser10 = new User(69429, "John", "Jameson", "JJame@AOL.com", "(131) 999-9999", "85937 fart Av. Buttstown");
	public static User myUser11 = new User(69430, "Jack", "Jones", "JJones@AOL.com", "(515) 999-9999", "98083 fart Av. Buttstown");
	public static User myUser12 = new User(69431, "Jim", "Sando", "JSan@AOL.com", "(168) 999-9999", "9893 fart Av. Buttstown");
	public static User myUser13 = new User(69432, "Jen", "Linda", "JLind@AOL.com", "(384) 999-9999", "2345 fart Av. Buttstown");
	public static User myUser14 = new User(69433, "Jan", "Rondo", "JRon@AOL.com", "(212) 999-9999", "2343 fart Av. Buttstown");
	public static User myUser15 = new User(69434, "Jimmy", "Remmington", "JRemm@AOL.com", "(443) 999-9999", "3421 fart Av. Buttstown");
	public static User myUser16 = new User(69435, "Jay", "Hara", "JHara@AOL.com", "(294) 999-9999", "54245 fart Av. Buttstown");
	public static User myUser17 = new User(69436, "Jerry", "Thomas", "JThom@AOL.com", "(845) 999-9999", "4542 fart Av. Buttstown");
	public static User myUser18 = new User(69437, "Alfred", "McCall", "AMcCall@AOL.com", "(103) 999-9999", "43245 fart Av. Buttstown");
	public static User myUser19 = new User(69438, "Ana", "Hemmings", "AHemm@AOL.com", "(756) 999-9999", "84356 fart Av. Buttstown");
	public static User myUser20 = new User(69439, "Ally", "Anderson", "AAnder@AOL.com", "(243) 999-9999", "3856 fart Av. Buttstown");
	public static User myUser21 = new User(69440, "Kendra", "Wayne", "KWayne@AOL.com", "(318) 999-9999", "1313 fart Av. Buttstown");
	public static Carpool myCarpool = new Carpool(0, 0, 0, null, null, null, null, null, null);



	static CarpoolDB myCarpools = new CarpoolDB(null);
	static ProfileDB myProfiles = new ProfileDB(null);

	/**
     * Main Method
     * @param args
     */
	public static void main(String[] args) {

		//For use with SQL Connector
	    String databaseurl = "jdbc:mysql://localhost:3306/carpooldatabase";
	    String username = "cs380lab1";
	    String password = "cs380";
	    Connection conn = null;
	    try{
	    	Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
	    	conn = DriverManager.getConnection(databaseurl, username, password);
	    	System.out.println("Bitch");

	    	 myCarpools = new CarpoolDB(conn);
			  myProfiles = new ProfileDB(conn);

			launch(args);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }


	}
}
