package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

import javafx.application.Application;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.awt.Desktop;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;


import java.io.File;
import java.net.URL;
import java.nio.file.Paths;
import java.util.ResourceBundle;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import java.net.URL;
import javafx.fxml.Initializable;
import java.util.ResourceBundle;

import OBJ.User.*;

/**
 * This is a class controller for the user profile scene
 * @author iann
 *
 */
public class UserProfileController extends SwitchHud implements Initializable{



	/**
	 *   jfx objects imported from the fxml scene
	 */
	@FXML // Buttons
	Button fileExplorerBtn1, fileExplorerBtn2, fileExplorerBtn3, fileExplorerBtn4, bLogOut;

	@FXML // Images
	ImageView pfp, CarExtImg, CarFrontImg, CarBackImg;

	@FXML // Text area for car bio
	TextArea BioArea;

	@FXML // editor editable text
	Text DriverNameLabel, PhoneNumLabel, EmailLabel, RidesCompletedLabel,
	RidesJoinedLabel, YearsJoinedlabel,	CarTypeLabel, PassengerSpace, LuggageSpace;

	@FXML // user editable text fields
	TextField EditedNameBox,
	EditedUserNameBox,
	EditedPasswordBox,
	EditedPhoneBox,
	EditedEmailBox,
	EditedPFPBox,
	EditedCarBox,
	EditedCarEBox,
	EditedCarFBox,
	EditedCarBBox,
	EditedPassengerSpaceBox,
	EditedLuggageSpaceBox;

	@FXML
	ScrollPane Scroller;

	private Stage stage;
	private Scene scene;
	private Parent root;



	/**
	 * This is the Initializer. Does stuff inside it when the scene loads
	 */
	@Override // actions which occour when the scene is loaded
	public void initialize(URL url, ResourceBundle resourceBundle){
		Scroller.setVvalue(0);
		DriverNameLabel.setText(DriverClass.myUser.getFirstName() + " " + DriverClass.myUser.getLastName());
		PhoneNumLabel.setText(DriverClass.myUser.getPhone());
		EmailLabel.setText(DriverClass.myUser.getEmail());
		CarTypeLabel.setText(DriverClass.myUser.getCarType());


		// this makes initialies file destination for the image. It needs to be local.
        String relativePath = "src/application/FlockGraphics604/inputPFP.png";
        String currentDirectory = System.getProperty("user.dir"); //other part of path from  users computer.
        currentDirectory = currentDirectory.replaceAll("\\\\", "/");
        String outputPath = Paths.get(currentDirectory, relativePath).toString();
        outputPath = outputPath.replaceAll("\\\\", "/");
        File outputFile = new File(outputPath);
        Image image = new Image(outputFile.toURI().toString());
        pfp.setImage(image);

		// this makes initialies file destination for the image. It needs to be local.
         relativePath = "src/application/FlockGraphics604/inputCarE.png";
         currentDirectory = System.getProperty("user.dir"); //other part of path from  users computer.
        currentDirectory = currentDirectory.replaceAll("\\\\", "/");
         outputPath = Paths.get(currentDirectory, relativePath).toString();
        outputPath = outputPath.replaceAll("\\\\", "/");
         outputFile = new File(outputPath);
         image = new Image(outputFile.toURI().toString());
        CarExtImg.setImage(image);

		// this makes initialies file destination for the image. It needs to be local.
         relativePath = "src/application/FlockGraphics604/inputCarF.png";
         currentDirectory = System.getProperty("user.dir"); //other part of path from  users computer.
        currentDirectory = currentDirectory.replaceAll("\\\\", "/");
         outputPath = Paths.get(currentDirectory, relativePath).toString();
        outputPath = outputPath.replaceAll("\\\\", "/");
         outputFile = new File(outputPath);
         image = new Image(outputFile.toURI().toString());
        CarFrontImg.setImage(image);

		// this makes initialies file destination for the image. It needs to be local.
         relativePath = "src/application/FlockGraphics604/inputCarB.png";
        currentDirectory = System.getProperty("user.dir"); //other part of path from  users computer.
        currentDirectory = currentDirectory.replaceAll("\\\\", "/");
         outputPath = Paths.get(currentDirectory, relativePath).toString();
        outputPath = outputPath.replaceAll("\\\\", "/");
         outputFile = new File(outputPath);
         image = new Image(outputFile.toURI().toString());
        CarBackImg.setImage(image);











		// need to add the image fields, but can move on
	}



	/**
	 * These take text from the editing page, and edits info accoardingly.
	 * 1 method per field
	 * @param event
	 * @throws IOException
	 */
	public void EditedName(ActionEvent event) throws IOException{

		// name to fist & last
		String[] nameSplitter = EditedNameBox.getText().split(" ");

		//fields
		DriverClass.myUser.setFirstName(nameSplitter[0]);
		DriverClass.myUser.setLastName(nameSplitter[1]);
		DriverNameLabel.setText(EditedNameBox.getText());
	}
	public void EditedPhone(ActionEvent event) throws IOException{
		DriverClass.myUser.setPhone(EditedPhoneBox.getText());
		PhoneNumLabel.setText(EditedPhoneBox.getText());
	}
	public void EditedEmail(ActionEvent event) throws IOException{
		DriverClass.myUser.setEmail(EditedEmailBox.getText());
		EmailLabel.setText(EditedEmailBox.getText());
	}
	public void EditedPFP(ActionEvent event) throws IOException{
		DriverClass.myUser.setpfpPath(EditedPFPBox.getText());
		//pfp.setText(EditedPFPBox.getText());
	}
	public void EditedCar(ActionEvent event) throws IOException{
		DriverClass.myUser.setCarType(EditedCarBox.getText());
		CarTypeLabel.setText(EditedCarBox.getText());
	}
	public void EditedPassengerSpace(ActionEvent event) throws IOException{
		DriverClass.myUser.setPassengerSpace(Integer.parseInt(EditedPassengerSpaceBox.getText()));
		PassengerSpace.setText(EditedPassengerSpaceBox.getText());
	}
	public void EditedLuggageSpace(ActionEvent event) throws IOException{
		DriverClass.myUser.setPassengerSpace(Integer.parseInt(EditedLuggageSpaceBox.getText()));
		LuggageSpace.setText(EditedLuggageSpaceBox.getText());
	}
	public void EditedCarE(ActionEvent event) throws IOException{
		DriverClass.myUser.setCarEPath(EditedCarEBox.getText());
		//pfp.setText(EditedPFPBox.getText());
	}
	public void EditedCarB(ActionEvent event) throws IOException{
		DriverClass.myUser.setCarBPath(EditedCarBBox.getText());
		//pfp.setText(EditedPFPBox.getText());
	}
	public void EditedCarF(ActionEvent event) throws IOException{
		DriverClass.myUser.setCarFPath(EditedCarFBox.getText());
		//pfp.setText(EditedPFPBox.getText());
	}
	public void EditedUser(ActionEvent event) throws IOException{
		//DriverClass.myUser.setCarFPath(EditedUserNameBox.getText());
		//pfp.setText(EditedPFPBox.getText());
	}
	public void EditedPass(ActionEvent event) throws IOException{
		//DriverClass.myUser.setCarFPath(EditedCarFBox.getText());
		//pfp.setText(EditedPFPBox.getText());
	}








	/**
	 * This section is an attempt at a file explorer prompt.
	 * If all goes well, users can select an image from file.
	 * @param event
	 * @throws IOException
	 */
	public void fileExplorerBtn1Act(ActionEvent event) throws IOException{

		/**
		 * This chunk opens a file explorer and imports an image to the scene
		 */
		// this does the file explorer stuff
		 FileChooser fileChooser = new FileChooser();
	        File selectedFile = fileChooser.showOpenDialog(stage);
	        if (selectedFile != null) {
	            String filePath = selectedFile.getAbsolutePath();
	            System.out.println("Selected File: " + filePath);
	        }

	        // takes edited path string, converts to usable image class, sets
	        String modifiedPath = "" + selectedFile;
	        modifiedPath = modifiedPath.replaceAll("\\\\", "/");// backslash is an escape character
	        File file = new File(modifiedPath);
	        Image image = new Image(file.toURI().toString());
			pfp.setImage(image);

			/**
			 * This chunk saves the image to the assets folder
			 */
			// Convert the JavaFX Image to BufferedImage. It has to be buffered or it wont work.
	        BufferedImage bufferedImage = new BufferedImage((int) image.getWidth(),(int) image.getHeight(),BufferedImage.TYPE_INT_ARGB);
	        BufferedImage convertedImage = SwingFXUtils.fromFXImage(image, bufferedImage);

	        // this makes a file destination for the image. It needs to be local.
	        String relativePath = "src/application/FlockGraphics604/inputPFP.png";
	        String currentDirectory = System.getProperty("user.dir"); //other part of path from  users computer.
	        currentDirectory = currentDirectory.replaceAll("\\\\", "/");
	        String outputPath = Paths.get(currentDirectory, relativePath).toString();
	        outputPath = outputPath.replaceAll("\\\\", "/");
	        File outputFile = new File(outputPath);

	        // this try catch attempts the actual file writing.
	        try {
	            // Save the BufferedImage to the output file using ImageIO
	            ImageIO.write(convertedImage, "png", outputFile);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	}

	/**
	 * This section is an attempt at a file explorer prompt.
	 * If all goes well, users can select an image from file.
	 * @param event
	 * @throws IOException
	 */
	public void fileExplorerBtn2Act(ActionEvent event) throws IOException{

		/**
		 * This chunk opens a file explorer and imports an image to the scene
		 */
		// this does the file explorer stuff
		 FileChooser fileChooser = new FileChooser();
	        File selectedFile = fileChooser.showOpenDialog(stage);
	        if (selectedFile != null) {
	            String filePath = selectedFile.getAbsolutePath();
	            System.out.println("Selected File: " + filePath);
	        }

	        // takes edited path string, converts to usable image class, sets
	        String modifiedPath = "" + selectedFile;
	        modifiedPath = modifiedPath.replaceAll("\\\\", "/");// backslash is an escape character
	        File file = new File(modifiedPath);
	        Image image = new Image(file.toURI().toString());
	        CarExtImg.setImage(image);

			/**
			 * This chunk saves the image to the assets folder
			 */
			// Convert the JavaFX Image to BufferedImage. It has to be buffered or it wont work.
	        BufferedImage bufferedImage = new BufferedImage((int) image.getWidth(),(int) image.getHeight(),BufferedImage.TYPE_INT_ARGB);
	        BufferedImage convertedImage = SwingFXUtils.fromFXImage(image, bufferedImage);

	        // this makes a file destination for the image. It needs to be local.
	        String relativePath = "src/application/FlockGraphics604/inputCarE.png";
	        String currentDirectory = System.getProperty("user.dir"); //other part of path from  users computer.
	        currentDirectory = currentDirectory.replaceAll("\\\\", "/");
	        String outputPath = Paths.get(currentDirectory, relativePath).toString();
	        outputPath = outputPath.replaceAll("\\\\", "/");
	        File outputFile = new File(outputPath);

	        // this try catch attempts the actual file writing.
	        try {
	            // Save the BufferedImage to the output file using ImageIO
	            ImageIO.write(convertedImage, "png", outputFile);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	}

	/**
	 * This section is an attempt at a file explorer prompt.
	 * If all goes well, users can select an image from file.
	 * @param event
	 * @throws IOException
	 */
	public void fileExplorerBtn3Act(ActionEvent event) throws IOException{

		/**
		 * This chunk opens a file explorer and imports an image to the scene
		 */
		// this does the file explorer stuff
		 FileChooser fileChooser = new FileChooser();
	        File selectedFile = fileChooser.showOpenDialog(stage);
	        if (selectedFile != null) {
	            String filePath = selectedFile.getAbsolutePath();
	            System.out.println("Selected File: " + filePath);
	        }

	        // takes edited path string, converts to usable image class, sets
	        String modifiedPath = "" + selectedFile;
	        modifiedPath = modifiedPath.replaceAll("\\\\", "/");// backslash is an escape character
	        File file = new File(modifiedPath);
	        Image image = new Image(file.toURI().toString());
	        CarFrontImg.setImage(image);

			/**
			 * This chunk saves the image to the assets folder
			 */
			// Convert the JavaFX Image to BufferedImage. It has to be buffered or it wont work.
	        BufferedImage bufferedImage = new BufferedImage((int) image.getWidth(),(int) image.getHeight(),BufferedImage.TYPE_INT_ARGB);
	        BufferedImage convertedImage = SwingFXUtils.fromFXImage(image, bufferedImage);

	        // this makes a file destination for the image. It needs to be local.
	        String relativePath = "src/application/FlockGraphics604/inputCarF.png";
	        String currentDirectory = System.getProperty("user.dir"); //other part of path from  users computer.
	        currentDirectory = currentDirectory.replaceAll("\\\\", "/");
	        String outputPath = Paths.get(currentDirectory, relativePath).toString();
	        outputPath = outputPath.replaceAll("\\\\", "/");
	        File outputFile = new File(outputPath);

	        // this try catch attempts the actual file writing.
	        try {
	            // Save the BufferedImage to the output file using ImageIO
	            ImageIO.write(convertedImage, "png", outputFile);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	}

	/**
	 * This section is an attempt at a file explorer prompt.
	 * If all goes well, users can select an image from file.
	 * @param event
	 * @throws IOException
	 */
	public void fileExplorerBtn4Act(ActionEvent event) throws IOException{

		/**
		 * This chunk opens a file explorer and imports an image to the scene
		 */
		// this does the file explorer stuff
		 FileChooser fileChooser = new FileChooser();
	        File selectedFile = fileChooser.showOpenDialog(stage);
	        if (selectedFile != null) {
	            String filePath = selectedFile.getAbsolutePath();
	            System.out.println("Selected File: " + filePath);
	        }

	        // takes edited path string, converts to usable image class, sets
	        String modifiedPath = "" + selectedFile;
	        modifiedPath = modifiedPath.replaceAll("\\\\", "/");// backslash is an escape character
	        File file = new File(modifiedPath);
	        Image image = new Image(file.toURI().toString());
	        CarBackImg.setImage(image);

			/**
			 * This chunk saves the image to the assets folder
			 */
			// Convert the JavaFX Image to BufferedImage. It has to be buffered or it wont work.
	        BufferedImage bufferedImage = new BufferedImage((int) image.getWidth(),(int) image.getHeight(),BufferedImage.TYPE_INT_ARGB);
	        BufferedImage convertedImage = SwingFXUtils.fromFXImage(image, bufferedImage);

	        // this makes a file destination for the image. It needs to be local.
	        String relativePath = "src/application/FlockGraphics604/inputCarB.png";
	        String currentDirectory = System.getProperty("user.dir"); //other part of path from  users computer.
	        currentDirectory = currentDirectory.replaceAll("\\\\", "/");
	        String outputPath = Paths.get(currentDirectory, relativePath).toString();
	        outputPath = outputPath.replaceAll("\\\\", "/");
	        File outputFile = new File(outputPath);

	        // this try catch attempts the actual file writing.
	        try {
	            // Save the BufferedImage to the output file using ImageIO
	            ImageIO.write(convertedImage, "png", outputFile);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	}




/**
 * This logs you out to the start screen
 * @param event
 * @throws IOException
 */
	public void LogOutBtn(ActionEvent event) throws IOException{
		Parent root = FXMLLoader.load(getClass().getResource("PhoneLogin.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

}
