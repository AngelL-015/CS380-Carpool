package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javax.swing.*;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Paths;
import java.sql.Driver;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class YourRideController extends SwitchHud implements Initializable{



	/**
	 * Editable text for data entry
	 */
	@FXML
	Text DriverLabel,
	LuggageSpaceLabel,
	DepartCityLabel,
	DepartTimeLabel,
	ArriveCityLabel,
	ArriveTimeLabel,
	PassengerSpaceLabel,
	// Names of passengers
	// Extra name variables should be empty
	// if there are less than 6 seats
	PassengerNameLabel1,
	PassengerNameLabel2,
	PassengerNameLabel3,
	PassengerNameLabel4,
	PassengerNameLabel5,
	PassengerNameLabel6;


	/**
	 * Images, also editable
	 */
	@FXML
	ImageView DriverPFPImage,
	CarPFPImage,
	// Pics of passengers
	// Extra pic variables should be empty
	// if there are less than 6 seats
	PassengerPFPImage1,
	PassengerPFPImage2,
	PassengerPFPImage3,
	PassengerPFPImage4,
	PassengerPFPImage5,
	PassengerPFPImage6;

	/**
	 * This may be used to cancel a booked ride.
	 * No implementation yet.
	 */
	@FXML // dont touch
	Button bRideCancel;


	@Override // actions which occour when the scene is loaded
	public void initialize(URL url, ResourceBundle resourceBundle){
		String fullName = DriverClass.myUser.getFirstName() + " " + DriverClass.myUser.getLastName();
		DriverLabel.setText(fullName);

			LuggageSpaceLabel.setText("" + DriverClass.myCarpool.getLuggageAmmount());
			ArriveCityLabel.setText(DriverClass.myCarpool.getDestination());
			DepartTimeLabel.setText(DriverClass.myCarpool.getPickupTime());
			DepartCityLabel.setText(DriverClass.myCarpool.getPickupLocation());
			ArriveTimeLabel.setText(DriverClass.myCarpool.getArrivalTime());
			PassengerSpaceLabel.setText("" + (DriverClass.myCarpool.getPassengerLimit() -DriverClass.myCarpool.getPassengerAmmount()));
			 fullName = DriverClass.myUser3.getFirstName() + " " + DriverClass.myUser3.getLastName();
			PassengerNameLabel1.setText(fullName);
			 fullName = DriverClass.myUser4.getFirstName() + " " + DriverClass.myUser4.getLastName();
			PassengerNameLabel2.setText(fullName);
			 fullName = DriverClass.myUser5.getFirstName() + " " + DriverClass.myUser5.getLastName();
			PassengerNameLabel3.setText(fullName);
			 fullName = DriverClass.myUser6.getFirstName() + " " + DriverClass.myUser6.getLastName();
			PassengerNameLabel4.setText(fullName);
			 fullName = DriverClass.myUser7.getFirstName() + " " + DriverClass.myUser7.getLastName();
			PassengerNameLabel5.setText(fullName);
			 fullName = DriverClass.myUser8.getFirstName() + " " + DriverClass.myUser8.getLastName();
			PassengerNameLabel6.setText(fullName);


			//sets pfp
	        String relativePath = "src/application/FlockGraphics604/inputPFP.png";
	        String currentDirectory = System.getProperty("user.dir"); //other part of path from  users computer.
	        currentDirectory = currentDirectory.replaceAll("\\\\", "/");
	        String outputPath = Paths.get(currentDirectory, relativePath).toString();
	        outputPath = outputPath.replaceAll("\\\\", "/");
	        File outputFile = new File(outputPath);
	        Image image = new Image(outputFile.toURI().toString());
	        DriverPFPImage.setImage(image);

			// sets car photo
			// this makes initialies file destination for the image. It needs to be local.
	         relativePath = "src/application/FlockGraphics604/inputCarE.png";
	         currentDirectory = System.getProperty("user.dir"); //other part of path from  users computer.
	        currentDirectory = currentDirectory.replaceAll("\\\\", "/");
	         outputPath = Paths.get(currentDirectory, relativePath).toString();
	        outputPath = outputPath.replaceAll("\\\\", "/");
	         outputFile = new File(outputPath);
	         image = new Image(outputFile.toURI().toString());
	         CarPFPImage.setImage(image);







	         /**
	          * passenger pfp's
	          */
	         relativePath = "src/application/FlockGraphics604/passenger6.jpg";
	         currentDirectory = System.getProperty("user.dir"); //other part of path from  users computer.
	        currentDirectory = currentDirectory.replaceAll("\\\\", "/");
	         outputPath = Paths.get(currentDirectory, relativePath).toString();
	        outputPath = outputPath.replaceAll("\\\\", "/");
	         outputFile = new File(outputPath);
	         image = new Image(outputFile.toURI().toString());
	         PassengerPFPImage6.setImage(image);
	         relativePath = "src/application/FlockGraphics604/passenger1.jpg";
	         currentDirectory = System.getProperty("user.dir"); //other part of path from  users computer.
	        currentDirectory = currentDirectory.replaceAll("\\\\", "/");
	         outputPath = Paths.get(currentDirectory, relativePath).toString();
	        outputPath = outputPath.replaceAll("\\\\", "/");
	         outputFile = new File(outputPath);
	         image = new Image(outputFile.toURI().toString());
	         PassengerPFPImage1.setImage(image);
	         relativePath = "src/application/FlockGraphics604/passenger2.jpg";
	         currentDirectory = System.getProperty("user.dir"); //other part of path from  users computer.
	        currentDirectory = currentDirectory.replaceAll("\\\\", "/");
	         outputPath = Paths.get(currentDirectory, relativePath).toString();
	        outputPath = outputPath.replaceAll("\\\\", "/");
	         outputFile = new File(outputPath);
	         image = new Image(outputFile.toURI().toString());
	         PassengerPFPImage2.setImage(image);
	         relativePath = "src/application/FlockGraphics604/passenger3.jpg";
	         currentDirectory = System.getProperty("user.dir"); //other part of path from  users computer.
	        currentDirectory = currentDirectory.replaceAll("\\\\", "/");
	         outputPath = Paths.get(currentDirectory, relativePath).toString();
	        outputPath = outputPath.replaceAll("\\\\", "/");
	         outputFile = new File(outputPath);
	         image = new Image(outputFile.toURI().toString());
	         PassengerPFPImage3.setImage(image);
	         relativePath = "src/application/FlockGraphics604/passenger4.jpg";
	         currentDirectory = System.getProperty("user.dir"); //other part of path from  users computer.
	        currentDirectory = currentDirectory.replaceAll("\\\\", "/");
	         outputPath = Paths.get(currentDirectory, relativePath).toString();
	        outputPath = outputPath.replaceAll("\\\\", "/");
	         outputFile = new File(outputPath);
	         image = new Image(outputFile.toURI().toString());
	         PassengerPFPImage4.setImage(image);
	         relativePath = "src/application/FlockGraphics604/passenger5.jpg";
	         currentDirectory = System.getProperty("user.dir"); //other part of path from  users computer.
	        currentDirectory = currentDirectory.replaceAll("\\\\", "/");
	         outputPath = Paths.get(currentDirectory, relativePath).toString();
	        outputPath = outputPath.replaceAll("\\\\", "/");
	         outputFile = new File(outputPath);
	         image = new Image(outputFile.toURI().toString());
	         PassengerPFPImage5.setImage(image);



	}



}
