/**
 * SwitchHud Class: Inherited class for switching between the 5 primary scenes.
 * @author Ian Nelson
 * Date 6/1/2023
 * CS380 Lab 5
 * Prof. Dovhalets
 *
 */


package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import java.io.IOException;
import javafx.stage.Stage;


/**
 * This is a parent for all other class controllers
 * @author iann
 */
public class SwitchHud {

	/**
	 *  Sets up window
	 */
	private Stage stage;
	private Scene scene;
	private Parent root;

	/**
	 *  this loads the buttons from the fxml files
	 */
	@FXML
	Button bUser, bWheel, bCar, bText, bPeep;





	/**
	 * these are all the fxml button methods.
	 * activates switching from 1 scene to the next.
	 * @param e | action event from pressing a button
	 */
	public void switchToUserProfileScene(ActionEvent event) throws IOException{
		Parent root = FXMLLoader.load(getClass().getResource("UserProfile.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	public void switchToYourRideScene(ActionEvent event) throws IOException{
		Parent root = FXMLLoader.load(getClass().getResource("YourRide.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	public void switchToDriveSelectionScene(ActionEvent event) throws IOException{
		Parent root = FXMLLoader.load(getClass().getResource("DriveSelection.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	public void switchToMapSelectionScene(ActionEvent event) throws IOException{
		Parent root = FXMLLoader.load(getClass().getResource("MapSelection.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	public void switchToPhoneReviewsScene(ActionEvent event) throws IOException{
		Parent root = FXMLLoader.load(getClass().getResource("PhoneReviews.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

}
