/**
 * Driver Class: Contians main method, and launches Stage to login scene.
 * @author Ian Nelson
 * Date 6/1/2023
 * CS380 Lab 5
 * Prof. Dovhalets
 *
 */

package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

import java.io.IOException;
import java.net.URL;
import java.sql.Driver;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import DB.CarpoolDB;
import DB.ProfileDB;
import OBJ.Carpool;
import OBJ.User;
import javafx.stage.Stage;


/**
 * ConfirmRideController contains methods for the Confirm Ride Scene
 * @author Ian Nelson
 *
 */
public class ConfirmRideController extends SwitchHud implements Initializable{


	@FXML // all editable text
	Text DriverLabel,
	DepartCityLabel,
	DepartTimeLabel,
	ArriveCityLabel,
	ArriveTimeLabel,
	luggageSpace,
	passengerSpace;

	@FXML // text fields editable by user in app.
	TextField numSeats, numSpace;

	@FXML
	ImageView DriverPFPImage;
	
	
	
	
	@Override // actions which occour when the scene is loaded
	public void initialize(URL url, ResourceBundle resourceBundle){




		try {

			updateLabels(DriverClass.myCarpools, DriverClass.myProfiles);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("sql excewption happenewd Owo");
			e.printStackTrace();
		}
	}

	/**
	 * Updates Ride Variables
	 * @author Angel
	 * @throws SQLException
	 */
	public void updateLabels(CarpoolDB cpDB, ProfileDB pfDB) throws SQLException {

		// Gets List of Carpools
		List<Carpool> carpools = new ArrayList<>();
		List<User> profiles = new ArrayList<>(); // Gets User Id

		carpools = cpDB.getCarpoolList();

		for(Carpool x:carpools) {
			profiles.add( pfDB.getUserById(x.getDriverID())); // Gets driver's profile & new funciton in ProfileDB
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	public void DriverLabel() throws IOException{
		String fullName = DriverClass.myUser2.getFirstName() + " " + DriverClass.myUser2.getLastName();
		DriverLabel.setText(fullName);
	}

	// Found in DriveSelectionController
	public void luggageSpace(ActionEvent event) throws IOException{
		luggageSpace.setText("" + DriverClass.myCarpool.getLuggageAmmount());
	}
	public void ArriveCityLabel(ActionEvent event) throws IOException{
		ArriveCityLabel.setText(DriverClass.myCarpool.getDestination());
	}
	public void DepartTimeLabel(ActionEvent event) throws IOException{
		DepartTimeLabel.setText(DriverClass.myCarpool.getPickupTime());
	}
	public void DepartCityLabel(ActionEvent event) throws IOException{
		DepartCityLabel.setText(DriverClass.myCarpool.getPickupLocation());
	}
	public void ArriveTimeLabel(ActionEvent event) throws IOException{
		ArriveTimeLabel.setText(DriverClass.myCarpool.getArrivalTime());
	}
	public void passengerSpace(ActionEvent event) throws IOException{
		passengerSpace.setText("" + (DriverClass.myCarpool.getPassengerLimit() -
				DriverClass.myCarpool.getPassengerAmmount()));
	}

















	/**
	 * these are methods to ensure that the seats/space a user
	 * enters does not exceed the max capacity
	 *
	 * havent put code in tho
	 * @param event
	 */

	public void NumSeatsAct(ActionEvent event){

	}
	public void NumSpaceAct(ActionEvent event){

	}




















	/**
	 * Dont touch
	 */
	@FXML // makes the scene switch
	Button bRidePicked;
	private Stage stage;
	private Scene scene;
	private Parent root;

	/**
	 * Dont touch
	 * Scene switch event method
	 * @param event | button press
	 * @throws IOException
	 */
	public void ConfirmBtn(ActionEvent event) throws IOException{
		Parent root = FXMLLoader.load(getClass().getResource("YourRide.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}



}