package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;

/*class Tupperware{
	   private ToggleButton bPlaceholder;
	   private ImageView sPlaceholder;

	   get
}*/

//	Foo[] array=new Foo[10];



public class MapSelectionController extends SwitchHud{
	@FXML
	Button bNext;

	@FXML
	ToggleButton tIssaquah, tSammamish, tRedmond, tKirkland, tNSeattle, tSSeattle,
					tMercer, tBellevue, tVashon, tKent, tFederalWay, tSpokane,
					tSpokaneValley, tWallaWalla, tPasco, tYakima, tEllensburg,
					tWenatchee, tChelan, tBellingham, tEverett, tTacoma, tOlympia,
					tVancouver;
	@FXML
	ToggleButton dummyButton;
	@FXML
	ImageView dummyStar;
	@FXML
	ImageView sIssaquah, sSammamish, sRedmond, sKirkland, sNSeattle, sSSeattle,
				sMercer, sBellevue, sVashon, sKent, sFederalWay, sSpokane,
				sSpokaneValley, sWallaWalla, sPasco, sYakima, sEllensburg,
				sWenatchee, sChelan, sBellingham, sEverett, sTacoma, sOlympia,
				sVancouver;


	//red.setHue(-0.50);

	private ToggleButton[] buttonHolder = new ToggleButton[1];
	private ImageView[] starHolder = new ImageView[1];
	private Stage stage;
	private Scene scene;
	private Parent root;




	public void NextBtn(ActionEvent event) throws IOException{
		Parent root = FXMLLoader.load(getClass().getResource("RidePicker.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}





	public void KirklandBtn(ActionEvent e){
		System.out.println("Kirkland");
		tButtonBlock(tKirkland, sKirkland);
	}

	public void NSeattleBtn(ActionEvent e){
		System.out.println("N. Seattle");
		tButtonBlock(tNSeattle, sNSeattle);
	}

	public void RedmondBtn(ActionEvent e){
		System.out.println("Redmond");
		tButtonBlock(tRedmond, sRedmond);


	}

	public void SammamishBtn(ActionEvent e){
		System.out.println("Sammamish");
		tButtonBlock(tSammamish, sSammamish);

	}

	public void BellevueBtn(ActionEvent e){
		System.out.println("Bellevue");
		tButtonBlock(tBellevue, sBellevue);
	}
	public void SSeattleBtn(ActionEvent e){
		System.out.println("S. Seattle");
		tButtonBlock(tSSeattle, sSSeattle);
	}
	public void MercerBtn(ActionEvent e){
		System.out.println("Mercer");
		tButtonBlock(tMercer, sMercer);
	}
	public void IssaquahBtn(ActionEvent e){
		System.out.println("Issaquah");
		tButtonBlock(tIssaquah, sIssaquah);
	}
	public void VashonBtn(ActionEvent e){
		System.out.println("Vashon");
		tButtonBlock(tVashon, sVashon);
	}
	public void KentBtn(ActionEvent e){
		System.out.println("Kent");
		tButtonBlock(tKent, sKent);
	}
	public void FederalWayBtn(ActionEvent e){
		System.out.println("Federal Way");
		tButtonBlock(tFederalWay, sFederalWay);
	}
	public void BellinghamBtn(ActionEvent e){
		System.out.println("Bellingham");
		tButtonBlock(tBellingham, sBellingham);
	}
	public void EverettBtn(ActionEvent e){
		System.out.println("Everett");
		tButtonBlock(tEverett, sEverett);
	}
	public void ChelanBtn(ActionEvent e){
		System.out.println("Chelan");
		tButtonBlock(tChelan, sChelan);
	}
	public void SpokaneBtn(ActionEvent e){
		System.out.println("Spokane");
		tButtonBlock(tSpokane, sSpokane);
	}
	public void SpokaneValleyBtn(ActionEvent e){
		System.out.println("Spokane Valley");
		tButtonBlock(tSpokaneValley, sSpokaneValley);
	}
	public void WenatcheeBtn(ActionEvent e){
		System.out.println("Wenatchee");
		tButtonBlock(tWenatchee, sWenatchee);
	}
	public void TacomaBtn(ActionEvent e){
		System.out.println("Tacoma");
		tButtonBlock(tTacoma, sTacoma);
	}
	public void OlympiaBtn(ActionEvent e){
		System.out.println("Olympia");
		tButtonBlock(tOlympia, sOlympia);
	}
	public void EllensburgBtn(ActionEvent e){
		System.out.println("Ellensburg");
		tButtonBlock(tEllensburg, sEllensburg);
	}
	public void YakimaBtn(ActionEvent e){
		System.out.println("Yakima");
		tButtonBlock(tYakima, sYakima);
	}
	public void PascoBtn(ActionEvent e){
		System.out.println("Pasco");
		tButtonBlock(tPasco, sPasco);
	}
	public void WallaWallaBtn(ActionEvent e){
		System.out.println("Walla Walla");
		tButtonBlock(tWallaWalla, sWallaWalla);
	}
	public void VancouverBtn(ActionEvent e){
		System.out.println("Vancouver");
		tButtonBlock(tVancouver, sVancouver);
	}



/*


	@FXML
	private RadioButton rButton1, rButton2, rButton3;
	@FXML
	private Label myLabelA, myLabelB;

	private String startDefined = "Point A";
	private String endDefined = "Point B";

	public void rButtonBlock(ActionEvent event){
		if(rButton1.isSelected() == true){
			if (startDefined.equals("Point A")){
				myLabelA.setText(rButton1.getText());
			}
			else{
				myLabelB.setText(rButton1.getText());
			}
		}
		else{
			if (startDefined.equals(rButton1.getText())){
				startDefined = "Point A";
			}
			if (endDefined.equals(rButton1.getText())){
				endDefined = "Point B";
			}
		}

	}
// imma do a bunch of logic
	// string fuckery

*/


	@FXML
	private Label myLabelA, myLabelB;

	public void tButtonBlock( ToggleButton tButton1, ImageView sImage1){
		try{
			if(tButton1.isSelected() == true){
				// fills in red box
				if (myLabelA.getText().equals("Point A")){
					myLabelA.setText(tButton1.getText());
					ColorAdjust recolorer = new ColorAdjust();
					recolorer.setHue(-0.70);
					sImage1.setEffect(recolorer);
				}
				// fills in green box


				else{
					// deselct button and blue star
					buttonHolder[0].setSelected(false);
					ColorAdjust recolorer = new ColorAdjust();
					recolorer.setHue(0.00);
					starHolder[0].setEffect(recolorer);



					// buttonholder holds current button, to unpress it later on autounpress
					myLabelB.setText(tButton1.getText());
					buttonHolder[0] = tButton1;


					// starholder holds current star, to blue it later on autounpress
					ColorAdjust recolorer2 = new ColorAdjust();
					recolorer2.setHue(0.70);
					sImage1.setEffect(recolorer2);
					starHolder[0] = sImage1;





				}
			}
			if(tButton1.isSelected() == false){
				System.out.println("144");
				if (myLabelA.getText().equals(tButton1.getText())){
					System.out.println("146");
					myLabelA.setText("Point A");

					// color set to blue
					ColorAdjust recolorer = new ColorAdjust();
					recolorer.setHue(0.00);
					sImage1.setEffect(recolorer);
				}
				if (myLabelB.getText().equals(tButton1.getText())){
					buttonHolder[0]= dummyButton;
					myLabelB.setText("Point B");

					//color
					starHolder[0]= dummyStar;
					ColorAdjust recolorer = new ColorAdjust();
					recolorer.setHue(0.00);
					sImage1.setEffect(recolorer);
				}
			}
		}
		catch(Exception nullPointerException){
			System.out.println("EXCEPTION HIT");
			buttonHolder[0]= dummyButton;
			starHolder[0]=dummyStar;
			tButtonBlock(tButton1, sImage1);
		}




		if (myLabelA.getText().equals("Point A") == false && myLabelB.getText().equals("Point B") == false){
			bNext.setDisable(false);
		}
		else{
			bNext.setDisable(true);
		}
	}





}
