package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;

/**
 * This is a class controller for the user profile scene
 * @author iann
 *
 */
public class UserProfileController extends SwitchHud{

	/**
	 *  this loads the buttons from the fxml file
	 */
	@FXML
	Button bUser, bWheel, bCar, bText, bPeep;

	@FXML
	ImageView pfp;


	private Stage stage;
	private Scene scene;
	private Parent root;







	public void LogOutBtn(ActionEvent event) throws IOException{
		 Image image = new Image(getClass().getResourceAsStream("/C:/Users/iann/Downloads/Chad.png"));
		pfp.setImage(image);
		/*Parent root = FXMLLoader.load(getClass().getResource("PhoneLogin.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();*/
	}

}
