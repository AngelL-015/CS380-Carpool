/**
 * Driver PhoneReveiwsController: Contians method for input and output of PhoneReveiws scene.
 * @author Ian Nelson
 * Date 6/1/2023
 * CS380 Lab 5
 * Prof. Dovhalets
 *
 */

package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;

/**
 * This is a class controller for the phoneReveiws scene
 * @author iann
 *
 */
public class PhoneReviewsController extends SwitchHud{

	@FXML // Labels at the top of the page
	Text DriverNameLabel, RidesCompletedLabel;

	@FXML // Pic at the top of the page
	ImageView DriverPFPImage;

	@FXML // Review messages, and name/time
	Text MessageTextLabel1, NameAndTimeLabel1, MessageTextLabel2, NameAndTimeLabel2,
		MessageTextLabel3, NameAndTime3, MessageTectLabel4,	NameAndTimeLabel4,
		MessageTextLabel5, NameAndTimeLabel5;

	@FXML // Review message stars, saved as image
	ImageView StarImage1, StarImage2, StarImage3, StarImage4, StarImage5;


}
