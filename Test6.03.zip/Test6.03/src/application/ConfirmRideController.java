/**
 * Driver Class: Contians main method, and launches Stage to login scene.
 * @author Ian Nelson
 * Date 6/1/2023
 * CS380 Lab 5
 * Prof. Dovhalets
 *
 */

package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

import java.io.IOException;
import javafx.stage.Stage;


/**
 * ConfirmRideController contains methods for the Confirm Ride Scene
 * @author Ian Nelson
 *
 */
public class ConfirmRideController extends SwitchHud{


	@FXML // all editable text 
	Text DriverLabel,
	DepartCityLabel,
	DepartTimeLabel,
	ArriveCityLabel,
	ArriveTimeLabel,
	luggageSpace,
	passengerSpace;
	
	@FXML // text fields editable by user in app.
	TextField numSeats, numSpace;
	
	@FXML
	ImageView DriverPFPImage;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * these are methods to ensure that the seats/space a user
	 * enters does not exceed the max capacity 
	 * 
	 * havent put code in tho
	 * @param event
	 */

	public void NumSeatsAct(ActionEvent event){

	}
	public void NumSpaceAct(ActionEvent event){

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	



	/**
	 * Dont touch
	 */
	@FXML // makes the scene switch
	Button bRidePicked;
	private Stage stage;
	private Scene scene;
	private Parent root;

	/**
	 * Dont touch
	 * Scene switch event method
	 * @param event | button press
	 * @throws IOException
	 */
	public void ConfirmBtn(ActionEvent event) throws IOException{
		Parent root = FXMLLoader.load(getClass().getResource("YourRide.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}



}
