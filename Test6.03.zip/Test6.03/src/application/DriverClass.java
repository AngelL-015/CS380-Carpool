/**
 * Driver ConfirmRideController: Contians method for input and output of ConfirmRide scene.
 * @author Ian Nelson
 * Date 6/1/2023
 * CS380 Lab 5
 * Prof. Dovhalets
 *
 */

package application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;


/**
 * look at the READ ME if you wanna know how to do a few things
 *
 */





/**
 * This class creates the stage, and loads the opening login scene.
 * @author Ian Nelson
 *
 */
public class DriverClass extends Application {

	/**
	 * Loads the stage window
	 * @param primaryStage | stage window
	 */
	@Override
	public void start(Stage primaryStage) throws Exception{



			/**
			 * This sets the name of the stage, and the frame in it.
			 */
			primaryStage.setTitle("Flock");
			Parent PhoneLoginScene = FXMLLoader.load(getClass().getResource("PhoneLogin.fxml"));
			primaryStage.setScene(new Scene(PhoneLoginScene,360,640));
			primaryStage.show();


	}



	/**
     * Main Method
     * @param args
     */
	public static void main(String[] args) {
		launch(args);
	}
}
