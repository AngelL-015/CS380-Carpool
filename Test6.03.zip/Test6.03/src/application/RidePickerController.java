package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class RidePickerController extends SwitchHud{
	@FXML
	Button bRidePicked;
	private Stage stage;
	private Scene scene;
	private Parent root;

	@FXML // first ride text
	Text FirstNameLabel1,
	LastNameLabel1,
	RidesCompletedLabel1,
	DepartWeekLabel1,
	DepartTimeLabel1,
	DepartAMPMLabel1,
	DepartCityLabel1,
	ArriveWeekLabel1,
	ArriveTimeLabel1,
	ArriveAMPMLabel1,
	ArriveCityLabel1;

	@FXML // Second ride text
	Text FirstNameLabel2,
	LastNameLabel2,
	RidesCompletedLabel2,
	DepartWeekLabel2,
	DepartTimeLabel2,
	DepartAMPMLabel2,
	DepartCityLabel2,
	ArriveWeekLabel2,
	ArriveTimeLabel2,
	ArriveAMPMLabel2,
	ArriveCityLabel2;

	@FXML // Third ride text
	Text FirstNameLabel3,
	LastNameLabel3,
	RidesCompletedLabel3,
	DepartWeekLabel3,
	DepartTimeLabel3,
	DepartAMPMLabel3,
	DepartCityLabel3,
	ArriveWeekLabel3,
	ArriveTimeLabel3,
	ArriveAMPMLabel3,
	ArriveCityLabel3;

	@FXML // Fourth ride text
	Text FirstNameLabel4,
	LastNameLabel4,
	RidesCompletedLabel4,
	DepartWeekLabel4,
	DepartTimeLabel4,
	DepartAMPMLabel4,
	DepartCityLabel4,
	ArriveWeekLabel4,
	ArriveTimeLabel4,
	ArriveAMPMLabel4,
	ArriveCityLabel4;

	@FXML // Fifth ride text
	Text FirstNameLabel5,
	LastNameLabel5,
	RidesCompletedLabel5,
	DepartWeekLabel5,
	DepartTimeLabel5,
	DepartAMPMLabel5,
	DepartCityLabel5,
	ArriveWeekLabel5,
	ArriveTimeLabel5,
	ArriveAMPMLabel5,
	ArriveCityLabel5;

	@FXML // Sixth
	Text FirstNameLabel6,
	LastNameLabel6,
	RidesCompletedLabel6,
	DepartWeekLabel6,
	DepartTimeLabel6,
	DepartAMPMLabel6,
	DepartCityLabel6,
	ArriveWeekLabel6,
	ArriveTimeLabel6,
	ArriveAMPMLabel6,
	ArriveCityLabel6;

	@FXML // 7
	Text FirstNameLabel7,
	LastNameLabel7,
	RidesCompletedLabel7,
	DepartWeekLabel7,
	DepartTimeLabel7,
	DepartAMPMLabel7,
	DepartCityLabel7,
	ArriveWeekLabel7,
	ArriveTimeLabel7,
	ArriveAMPMLabel7,
	ArriveCityLabel7;

	@FXML // 8
	Text FirstNameLabel8,
	LastNameLabel8,
	RidesCompletedLabel8,
	DepartWeekLabel8,
	DepartTimeLabel8,
	DepartAMPMLabel8,
	DepartCityLabel8,
	ArriveWeekLabel8,
	ArriveTimeLabel8,
	ArriveAMPMLabel8,
	ArriveCityLabel8;

	@FXML // 9
	Text FirstNameLabel9,
	LastNameLabel9,
	RidesCompletedLabel9,
	DepartWeekLabel9,
	DepartTimeLabel9,
	DepartAMPMLabel9,
	DepartCityLabel9,
	ArriveWeekLabel9,
	ArriveTimeLabel9,
	ArriveAMPMLabel9,
	ArriveCityLabel9;

	@FXML // 10
	Text FirstNameLabelA,
	LastNameLabelA,
	RidesCompletedLabelA,
	DepartWeekLabelA,
	DepartTimeLabelA,
	DepartAMPMLabelA,
	DepartCityLabelA,
	ArriveWeekLabelA,
	ArriveTimeLabelA,
	ArriveAMPMLabelA,
	ArriveCityLabelA;












	/**
	 * DONT TOUCH THIS
	 * RidePickedBtn sends user to the confirmation screen
	 * @param event | button press
	 * @throws IOException
	 */
	public void RidePickedBtn(ActionEvent event) throws IOException{
		Parent root = FXMLLoader.load(getClass().getResource("ConfirmRide.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}



}
