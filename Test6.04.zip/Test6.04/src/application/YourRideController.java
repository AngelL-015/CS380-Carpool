package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class YourRideController extends SwitchHud{



	/**
	 * Editable text for data entry
	 */
	@FXML
	Text DriverLabel,
	LuggageSpaceLabel,
	DepartCityLabel,
	DepartTimeLabel,
	ArriveCityLabel,
	ArriveTimeLabel,
	PassengerSpaceLabel,
	// Names of passengers
	// Extra name variables should be empty
	// if there are less than 6 seats
	PassengerNameLabel1,
	PassengerNameLabel2,
	PassengerNameLabel3,
	PassengerNameLabel4,
	PassengerNameLabel5,
	PassengerNameLabel6;


	/**
	 * Images, also editable
	 */
	@FXML
	ImageView DriverPFPImage,
	CarPFPImage,
	// Pics of passengers
	// Extra pic variables should be empty
	// if there are less than 6 seats
	PassengerPFPImage1,
	PassengerPFPImage2,
	PassengerPFPImage3,
	PassengerPFPImage4,
	PassengerPFPImage5,
	PassengerPFPImage6;

	/**
	 * This may be used to cancel a booked ride.
	 * No implementation yet.
	 */
	@FXML // dont touch
	Button bRideCancel;


}
