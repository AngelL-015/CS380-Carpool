READ ME



This GUI stuff is kinda like a play, The window is our stage, and each scene is a collection
of different props and backdrops. One stage, decorated with multiple scenes.
 
The FXML files are NOT IN JAVA, but their own proprietary language to javafx
They graph out what a scene is supposed to look like. So a blueprint.
Don't mess with them too much, and keep backups. Save often, cuz they break
 
If you want to use them with scenebuilder, it's an easy download. 
just an executable.
https://gluonhq.com/products/scene-builder/

I'd also suggest downloading the prebuilt plugins, it saved me a lot of time and headaches.
https://efxclipse.bestsolution.at/install.html#all-in-one
It's the 2016 build of eclipse, but its got everything you need to integrate scenebuilder.
Think "ol' reliable"


if you want more tips, this youtube channel got nice tutorials
https://www.youtube.com/watch?v=_7OM-cMYWbQ&list=PLZPZq0r_RZOM-8vJA3NQFZB7JroDcMwev



 The Controller Java Files correspond to each FXML file.
 Simply, they are where the code goes.
 The FXML's contain the buttons and textboxes etc, but without stuff in the controller files
 none of that is gonna work.
 If you need help with something in there, look it up, check out some of oracles doc's or just ping me.


For data entry. 
My suggestion, I'm gonna take the fxml files and basically replace the text with a descriptor of what the text should be.
